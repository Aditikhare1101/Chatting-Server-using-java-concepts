package loginform;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import signupform.signup;
import java.awt.event.*;

public class login extends JFrame {
	protected static final JLabel textuser = null;
	private JPanel contentPane;
	private JTextField textField;
	protected JLabel textpass;
	private JPasswordField passwordField;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					login frame = new login();
					frame.setVisible(true);
				} catch (Exception e) {e.printStackTrace();}
			}
		});
	}

	public login() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1002, 463);
		contentPane = new JPanel();
		contentPane.setBackground(Color.BLACK);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.BLACK);
		panel.setBounds(511, 0, 477, 426);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("LOGIN ACCOUNT");
		lblNewLabel.setBounds(78, 22, 356, 43);
		panel.add(lblNewLabel);
		lblNewLabel.setForeground(Color.WHITE);
		lblNewLabel.setFont(new Font("Sitka Small", Font.BOLD, 34));
		
		JLabel lblNewLabel_1 = new JLabel("USER NAME: ");
		lblNewLabel_1.setForeground(Color.WHITE);
		lblNewLabel_1.setBounds(44, 92, 200, 43);
		panel.add(lblNewLabel_1);
		lblNewLabel_1.setFont(new Font("Times New Roman", Font.BOLD, 28));
		
		textField = new JTextField();
		textField.setBounds(44, 145, 414, 37);
		panel.add(textField);
		textField.setFont(new Font("Yu Gothic", Font.PLAIN, 28));
		textField.setColumns(10);
		
		JLabel lblNewLabel_1_1 = new JLabel("PASSWORD: ");
		lblNewLabel_1_1.setForeground(Color.WHITE);
		lblNewLabel_1_1.setBounds(44, 203, 200, 43);
		panel.add(lblNewLabel_1_1);
		lblNewLabel_1_1.setFont(new Font("Times New Roman", Font.BOLD, 28));
		
		passwordField = new JPasswordField();
		passwordField.setBounds(43, 256, 404, 37);
		panel.add(passwordField);
		passwordField.setFont(new Font("Yu Gothic", Font.PLAIN, 28));
		
		JButton btnNewButton_1 = new JButton("Create an Account");
		btnNewButton_1.setBounds(275, 336, 183, 51);
		panel.add(btnNewButton_1);
		btnNewButton_1.setBackground(Color.LIGHT_GRAY);
		btnNewButton_1.setForeground(Color.BLACK);
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				signup s=new signup();
				s.setVisible(true);
			}
		});
		btnNewButton_1.setFont(new Font("Tahoma", Font.PLAIN, 18));
		
		JButton btnNewButton = new JButton("Login ");
		btnNewButton.setBounds(44, 334, 158, 51);
		panel.add(btnNewButton);
		btnNewButton.setBackground(Color.LIGHT_GRAY);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String username= textField.getText();
				String password= passwordField.getText();
				
				if(username.equals("Itachi" ) && password.equals("Uchiha")) {
					HomePage h = new HomePage();
					h.setVisible(true);
					JOptionPane.showMessageDialog(null, " You have successfully logged in ");
					h.setVisible(true);
				}else if(username.equals("Naruto" ) && password.equals("Uzumaki")) {
					HomePage h = new HomePage();
					h.setVisible(true);
					JOptionPane.showMessageDialog(null, " You have successfully logged in ");
				}else if(username.equals("Kakashi" ) && password.equals("Hatake")) {
					HomePage h = new HomePage();
					h.setVisible(true);
					JOptionPane.showMessageDialog(null, " You have successfully logged in ");
				}else if(username.equals("Obito" ) && password.equals("Uchiha")) {
					HomePage h = new HomePage();
					h.setVisible(true);
					JOptionPane.showMessageDialog(null, " You have successfully logged in ");
				}else if(username.equals("Sasuke" ) && password.equals("Uchiha")) {
					HomePage h = new HomePage();
					h.setVisible(true);
					JOptionPane.showMessageDialog(null, " You have successfully logged in ");
				}else {
					JOptionPane.showMessageDialog(null, " Try again ");
				}
			}
		});
		btnNewButton.setFont(new Font("Times New Roman", Font.PLAIN, 28));
		btnNewButton.setForeground(Color.BLACK);
		JLabel lblNewLabel_2 = new JLabel("New label");
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2.setIcon(new ImageIcon(login.class.getResource("/loginform/images/lockscreen.jpg")));
		lblNewLabel_2.setBounds(10, 10, 491, 398);
		contentPane.add(lblNewLabel_2);
		JLabel lblNewLabel_3 = new JLabel("New label");
		lblNewLabel_3.setBounds(127, 163, 45, 13);
		contentPane.add(lblNewLabel_3);
	}
}
