package loginform;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.*;
import javax.swing.event.AncestorListener;
import javax.swing.event.AncestorEvent;

public class HomePage extends JFrame{

	private JPanel contentPane;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					HomePage frame = new HomePage();
					frame.setVisible(true);
				} catch (Exception e) {e.printStackTrace();}
			}
		});
	}

	public HomePage() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 493, 780);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(0, 0, 0));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);


		JButton btnAditi = new JButton("  Madara Uchiha");
		btnAditi.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		btnAditi.setBackground(new Color(242, 77, 0));btnAditi.setIcon(new ImageIcon(HomePage.class.getResource("/loginform/images/Madara2.png")));
		btnAditi.setHorizontalAlignment(SwingConstants.LEFT);
		btnAditi.setForeground(Color.BLACK);
		btnAditi.setFont(new Font("Tahoma", Font.ITALIC, 20));
		btnAditi.setBounds(10, 81, 455, 105);

		contentPane.add(btnAditi);

		JButton btnNewButton = new JButton("   Obito Uchiha");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		btnNewButton.setBackground(new Color(242, 77, 0));
		btnNewButton.setFont(new Font("Tahoma", Font.ITALIC, 20));
		btnNewButton.setBounds(10, 189, 455, 105);
		btnNewButton.setForeground(new Color(0, 0, 0));
		btnNewButton.setHorizontalAlignment(SwingConstants.LEFT);
		btnNewButton.setIcon(new ImageIcon(HomePage.class.getResource("/loginform/images/obrin.jpg")));

		contentPane.add(btnNewButton);

		JButton btnRiya = new JButton("   Kakashi Hatake");
		btnRiya.setBackground(new Color(242, 77, 0));
		btnRiya.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		btnRiya.setIcon(new ImageIcon(HomePage.class.getResource("/loginform/images/kakashi (2).jpg")));
		btnRiya.setHorizontalAlignment(SwingConstants.LEFT);
		btnRiya.setForeground(Color.BLACK);
		btnRiya.setFont(new Font("Tahoma", Font.ITALIC, 20));
		btnRiya.setBounds(10, 297, 455, 100);
		contentPane.add(btnRiya);

		JButton btnBhakti = new JButton("  Sasuke Uchiha ");
		btnBhakti.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		btnBhakti.setBackground(new Color(242, 77, 0));
		btnBhakti.setIcon(new ImageIcon(HomePage.class.getResource("/loginform/images/sasuke.png")));
		btnBhakti.setHorizontalAlignment(SwingConstants.LEFT);
		btnBhakti.setForeground(Color.BLACK);
		btnBhakti.setFont(new Font("Tahoma", Font.ITALIC, 20));
		btnBhakti.setBounds(10, 400, 455, 105);
		contentPane.add(btnBhakti);

		JButton btnJavaProject = new JButton("   Naruto Shippuden");
		btnJavaProject.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});

		JButton btnNewButton_5 = new JButton("   Naruto Uzumaki");
		btnNewButton_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		btnNewButton_5.setBackground(new Color(242, 77, 0));
		btnNewButton_5.setIcon(new ImageIcon(HomePage.class.getResource("/loginform/images/naruto.jpg")));
		btnNewButton_5.setHorizontalAlignment(SwingConstants.LEFT);
		btnNewButton_5.setForeground(Color.BLACK);
		btnNewButton_5.setFont(new Font("Tahoma", Font.ITALIC, 20));
		btnNewButton_5.setBounds(10, 615, 455, 105);
		contentPane.add(btnNewButton_5);

		btnJavaProject.setBackground(new Color(242, 77, 0));
		btnJavaProject.setIcon(new ImageIcon(HomePage.class.getResource("/loginform/images/NarutoS.jpg")));
		btnJavaProject.setHorizontalAlignment(SwingConstants.LEFT);
		btnJavaProject.setForeground(Color.BLACK);
		btnJavaProject.setFont(new Font("Tahoma", Font.ITALIC, 20));
		btnJavaProject.setBounds(10, 508, 455, 105);
		contentPane.add(btnJavaProject);

		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setIcon(new ImageIcon(HomePage.class.getResource("/loginform/images/itachmi_01.jpg")));
		lblNewLabel.setBackground(Color.BLACK);
		lblNewLabel.setBounds(10, 10, 66, 61);
		contentPane.add(lblNewLabel);

		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setIcon(new ImageIcon(HomePage.class.getResource("/loginform/images/search.png")));
		lblNewLabel_1.setBounds(362, 10, 50, 61);
		contentPane.add(lblNewLabel_1);

		JLabel lblNewLabel_2 = new JLabel("");
		lblNewLabel_2.addAncestorListener(new AncestorListener() {
			public void ancestorAdded(AncestorEvent event) {}
			public void ancestorMoved(AncestorEvent event) {}
			public void ancestorRemoved(AncestorEvent event) {}
		});
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2.setIcon(new ImageIcon(HomePage.class.getResource("/loginform/images/3icon (1).png")));
		lblNewLabel_2.setBackground(Color.BLACK);
		lblNewLabel_2.setBounds(422, 22, 27, 38);
		contentPane.add(lblNewLabel_2);

	}
}