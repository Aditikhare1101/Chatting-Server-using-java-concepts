package page1.icons;

import javax.swing.*;
import loginform.*;
import java.awt.*;

public class page {
    public static void main(String[] args) {
        splashframe f1 = new splashframe();
        f1.setVisible(true);
        int i;
        int x = 1;
        for(i = 1; i <= 800; i += 10, x += 7){
        f1.setBounds(10,20,i,i);
            try{
                Thread.sleep(7);
            }catch(Exception e){e.printStackTrace();}
        }

    }
}

class splashframe extends JFrame implements Runnable{
    Thread t1;
    splashframe(){
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("page1/icons/LoginpageICON.jpg"));
        Image i2 = i1.getImage().getScaledInstance(800,800,1000);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel l1 = new JLabel(i3);
        add(l1);

        setUndecorated(true);
        t1 = new Thread(this);
        t1.start();
    }

    @Override
    public void run() {
        try{
            Thread.sleep(5000);
            this.setVisible(false);
            login l = new login();
            l.setVisible(true);
        }catch(Exception e){
            e.printStackTrace();
        }
    }
}
